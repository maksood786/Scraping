import PIL
import pytesseract

pytesseract.tesseract_cmd = 'C:/Program Files/Tesseract-OCR/tesseract.exe'
output = pytesseract.image_to_string(PIL.Image.open('ie-architecture.png').convert("RGB"), lang='eng')
print(output)